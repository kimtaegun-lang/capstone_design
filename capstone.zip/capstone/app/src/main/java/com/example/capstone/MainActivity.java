package com.example.capstone;
import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private BroadcastReceiver broadcastReceiver; // broadcast 변수
    private Button btnRecord; // 녹음 버튼 id
    private Button gptButton;   // gpt 버튼 id
    private TextView textView; // 텍스트 뷰 id
    Boolean isListening = FALSE; // 플래그 변수
    String recognizedText; // 음성 녹음을 통해 받아온 변수
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnRecord = findViewById(R.id.btn_record); // 각 객체에 id 부여
        textView = findViewById(R.id.text_result);
        gptButton=findViewById(R.id.btn_gpt);

        btnRecord.setOnClickListener(new View.OnClickListener() { // 녹음버튼 클릭시 시작하는 부분
            @Override
            public void onClick(View view) {
                if (isListening) { // 녹음 종료 시
                    isListening = FALSE;
                    btnRecord.setText("녹음시작");
                    Toast.makeText(MainActivity.this, "음성 인식 종료", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this, Foreground.class);
                    stopService(intent);
                } else if (!isListening) { // 녹음 시작시
                    isListening = TRUE;
                    btnRecord.setText("종료");
                    Toast.makeText(MainActivity.this, "음성 인식 시작", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this, Foreground.class);
                    startService(intent);
                }
            }
        });

        // BroadcastReceiver 생성 및 등록(Foreground.java->MainActivity.java로 녹음된 텍스트 전달)
        broadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent.getAction().equals("STT_RESULT")) {
                    recognizedText = intent.getStringExtra("recognizedText"); // 텍스트 받아오는 구문
                    textView.setText(recognizedText);  // 텍스트뷰에 표시
                }
            }
        };
        registerReceiver(broadcastReceiver, new IntentFilter("STT_RESULT"));  // 커스텀 액션 필터 설정
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(broadcastReceiver);  // BroadcastReceiver 등록 해제
    }
}